var APP_DATA = {
  "scenes": [
    {
      "id": "0-algis-1rgb_color",
      "name": "algis 1.RGB_color",
      "levels": [
        {
          "tileSize": 256,
          "size": 256,
          "fallbackOnly": true
        },
        {
          "tileSize": 512,
          "size": 512
        },
        {
          "tileSize": 512,
          "size": 1024
        }
      ],
      "faceSize": 1000,
      "initialViewParameters": {
        "yaw": -0.8832945405032717,
        "pitch": -0.03126503430307892,
        "fov": 1.4134061960355204
      },
      "linkHotspots": [
        {
          "yaw": -0.7489250370458489,
          "pitch": 0.048069580194951556,
          "rotation": 0,
          "target": "1-algis-2"
        }
      ],
      "infoHotspots": []
    },
    {
      "id": "1-algis-2",
      "name": "algis 2",
      "levels": [
        {
          "tileSize": 256,
          "size": 256,
          "fallbackOnly": true
        },
        {
          "tileSize": 512,
          "size": 512
        },
        {
          "tileSize": 512,
          "size": 1024
        }
      ],
      "faceSize": 1000,
      "initialViewParameters": {
        "yaw": -0.9835236315983078,
        "pitch": -0.0055139383460449665,
        "fov": 1.4134061960355204
      },
      "linkHotspots": [
        {
          "yaw": -1.68850299262364,
          "pitch": 0.0020303171564037825,
          "rotation": 0,
          "target": "2-algis-3"
        }
      ],
      "infoHotspots": []
    },
    {
      "id": "2-algis-3",
      "name": "algis 3",
      "levels": [
        {
          "tileSize": 256,
          "size": 256,
          "fallbackOnly": true
        },
        {
          "tileSize": 512,
          "size": 512
        },
        {
          "tileSize": 512,
          "size": 1024
        }
      ],
      "faceSize": 1000,
      "initialViewParameters": {
        "yaw": 3.0637423720370993,
        "pitch": 0.04533269749075686,
        "fov": 1.4134061960355204
      },
      "linkHotspots": [
        {
          "yaw": 2.2922156964314233,
          "pitch": 0.055320275947064346,
          "rotation": 0,
          "target": "3-algis-4"
        }
      ],
      "infoHotspots": []
    },
    {
      "id": "3-algis-4",
      "name": "algis 4",
      "levels": [
        {
          "tileSize": 256,
          "size": 256,
          "fallbackOnly": true
        },
        {
          "tileSize": 512,
          "size": 512
        },
        {
          "tileSize": 512,
          "size": 1024
        }
      ],
      "faceSize": 1000,
      "initialViewParameters": {
        "yaw": 0,
        "pitch": 0,
        "fov": 1.4134061960355204
      },
      "linkHotspots": [
        {
          "yaw": -0.729986506282021,
          "pitch": 0.07432605485997001,
          "rotation": 0,
          "target": "4-algis-5"
        }
      ],
      "infoHotspots": []
    },
    {
      "id": "4-algis-5",
      "name": "algis 5",
      "levels": [
        {
          "tileSize": 256,
          "size": 256,
          "fallbackOnly": true
        },
        {
          "tileSize": 512,
          "size": 512
        },
        {
          "tileSize": 512,
          "size": 1024
        }
      ],
      "faceSize": 1000,
      "initialViewParameters": {
        "yaw": 0,
        "pitch": 0,
        "fov": 1.4134061960355204
      },
      "linkHotspots": [],
      "infoHotspots": []
    }
  ],
  "name": "Project Title",
  "settings": {
    "mouseViewMode": "drag",
    "autorotateEnabled": true,
    "fullscreenButton": false,
    "viewControlButtons": false
  }
};
